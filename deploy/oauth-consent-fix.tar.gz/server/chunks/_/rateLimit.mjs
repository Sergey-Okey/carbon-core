import { i as getRequestIP, e as createError } from './nitro.mjs';

const attempts = /* @__PURE__ */ new Map();
function enforceRateLimit(event, scope, limit, windowMs) {
  const now = Date.now();
  const key = `${scope}:${getRequestIP(event, { xForwardedFor: true }) || "unknown"}`;
  const current = attempts.get(key);
  if (!current || current.resetAt <= now) {
    attempts.set(key, { count: 1, resetAt: now + windowMs });
    return;
  }
  if (current.count >= limit) {
    throw createError({ statusCode: 429, statusMessage: "Too many requests. Try again later." });
  }
  current.count += 1;
}

export { enforceRateLimit as e };
//# sourceMappingURL=rateLimit.mjs.map
