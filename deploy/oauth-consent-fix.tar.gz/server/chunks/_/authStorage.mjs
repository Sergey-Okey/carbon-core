import { e as createError, u as useRuntimeConfig } from './nitro.mjs';
import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import { g as getDatabase } from './database.mjs';

function isAuthDatabaseConfigured() {
  return Boolean(getDatabase()) && useRuntimeConfig().authSessionSecret.trim().length >= 32;
}
async function ensureUsersTable(sql) {
  await sql`
    CREATE TABLE IF NOT EXISTS cof_users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT,
      name TEXT NOT NULL,
      avatar TEXT NOT NULL DEFAULT '',
      provider TEXT NOT NULL,
      provider_id TEXT,
      terms_accepted_at TIMESTAMPTZ,
      terms_version TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `;
  await sql`ALTER TABLE cof_users ADD COLUMN IF NOT EXISTS terms_accepted_at TIMESTAMPTZ`;
  await sql`ALTER TABLE cof_users ADD COLUMN IF NOT EXISTS terms_version TEXT`;
  await sql`
    CREATE UNIQUE INDEX IF NOT EXISTS cof_users_provider_identity
    ON cof_users(provider, provider_id)
    WHERE provider_id IS NOT NULL
  `;
}
async function registerAccount(email, password, name, termsVersion) {
  const sql = getDatabase();
  if (!sql) throw createError({ statusCode: 503, statusMessage: "Account database is not configured" });
  await ensureUsersTable(sql);
  const normalizedEmail = email.trim().toLowerCase();
  const existing = await sql`SELECT id FROM cof_users WHERE email = ${normalizedEmail} LIMIT 1`;
  if (existing.length) throw createError({ statusCode: 409, statusMessage: "Email is already registered" });
  const id = `local:${randomBytes(16).toString("hex")}`;
  const rows = await sql`
    INSERT INTO cof_users (id, email, password_hash, name, provider, terms_accepted_at, terms_version)
    VALUES (${id}, ${normalizedEmail}, ${hashPassword(password)}, ${name.trim()}, 'local', NOW(), ${termsVersion})
    RETURNING id, email, name, avatar, provider, created_at
  `;
  return mapAccount(rows[0]);
}
async function loginAccount(email, password) {
  const sql = getDatabase();
  if (!sql) throw createError({ statusCode: 503, statusMessage: "Account database is not configured" });
  await ensureUsersTable(sql);
  const rows = await sql`
    SELECT id, email, password_hash, name, avatar, provider, created_at
    FROM cof_users
    WHERE email = ${email.trim().toLowerCase()}
    LIMIT 1
  `;
  const row = rows[0];
  if (!(row == null ? void 0 : row.password_hash) || !verifyPassword(password, String(row.password_hash))) {
    throw createError({ statusCode: 401, statusMessage: "Invalid email or password" });
  }
  return mapAccount(row);
}
async function upsertOAuthAccount(profile, termsVersion = "") {
  const sql = getDatabase();
  if (!sql) return { ...profile, createdAt: (/* @__PURE__ */ new Date()).toISOString() };
  await ensureUsersTable(sql);
  const providerId = profile.id.slice(profile.provider.length + 1);
  const existing = await sql`SELECT id FROM cof_users WHERE id = ${profile.id} LIMIT 1`;
  if (!existing.length && termsVersion !== "2026-06-07") {
    throw createError({ statusCode: 403, statusMessage: "Terms consent is required" });
  }
  const rows = await sql`
    INSERT INTO cof_users (
      id, email, name, avatar, provider, provider_id, terms_accepted_at, terms_version
    )
    VALUES (
      ${profile.id}, ${profile.email.toLowerCase()}, ${profile.name}, ${profile.avatar},
      ${profile.provider}, ${providerId}, NOW(), ${termsVersion}
    )
    ON CONFLICT (id)
    DO UPDATE SET
      email = EXCLUDED.email,
      name = EXCLUDED.name,
      avatar = EXCLUDED.avatar,
      updated_at = NOW()
    RETURNING id, email, name, avatar, provider, created_at
  `;
  return mapAccount(rows[0]);
}
async function updateAccount(id, updates) {
  var _a, _b, _c;
  const sql = getDatabase();
  if (!sql) throw createError({ statusCode: 503, statusMessage: "Account database is not configured" });
  await ensureUsersTable(sql);
  const currentRows = await sql`
    SELECT id, email, name, avatar, provider, created_at FROM cof_users WHERE id = ${id} LIMIT 1
  `;
  const current = currentRows[0];
  if (!current) throw createError({ statusCode: 404, statusMessage: "Account not found" });
  const email = ((_a = updates.email) == null ? void 0 : _a.trim().toLowerCase()) || String(current.email);
  const name = ((_b = updates.name) == null ? void 0 : _b.trim()) || String(current.name);
  const avatar = (_c = updates.avatar) != null ? _c : String(current.avatar || "");
  try {
    const rows = await sql`
      UPDATE cof_users
      SET email = ${email}, name = ${name}, avatar = ${avatar}, updated_at = NOW()
      WHERE id = ${id}
      RETURNING id, email, name, avatar, provider, created_at
    `;
    return mapAccount(rows[0]);
  } catch {
    throw createError({ statusCode: 409, statusMessage: "Email is already in use" });
  }
}
async function deleteAccount(id) {
  const sql = getDatabase();
  if (!sql) throw createError({ statusCode: 503, statusMessage: "Account database is not configured" });
  await ensureUsersTable(sql);
  await sql`
    CREATE TABLE IF NOT EXISTS cof_sync_state (
      user_id TEXT PRIMARY KEY,
      payload JSONB NOT NULL DEFAULT '{}'::jsonb,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `;
  await sql`DELETE FROM cof_sync_state WHERE user_id = ${id}`;
  await sql`DELETE FROM cof_users WHERE id = ${id}`;
}
function hashPassword(password) {
  const salt = randomBytes(16);
  const derived = scryptSync(password, salt, 64);
  return `scrypt:${salt.toString("hex")}:${derived.toString("hex")}`;
}
function verifyPassword(password, stored) {
  const [algorithm, saltHex, hashHex] = stored.split(":");
  if (algorithm !== "scrypt" || !saltHex || !hashHex) return false;
  const expected = Buffer.from(hashHex, "hex");
  const actual = scryptSync(password, Buffer.from(saltHex, "hex"), expected.length);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
function mapAccount(row) {
  return {
    id: String(row.id),
    email: String(row.email),
    name: String(row.name),
    avatar: String(row.avatar || ""),
    provider: String(row.provider),
    createdAt: new Date(String(row.created_at)).toISOString()
  };
}

export { updateAccount as a, deleteAccount as d, isAuthDatabaseConfigured as i, loginAccount as l, registerAccount as r, upsertOAuthAccount as u };
//# sourceMappingURL=authStorage.mjs.map
