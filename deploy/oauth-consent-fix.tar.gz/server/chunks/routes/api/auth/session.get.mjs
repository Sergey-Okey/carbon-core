import { c as defineEventHandler } from '../../../_/nitro.mjs';
import { r as readOAuthSession } from '../../../_/oauth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const session_get = defineEventHandler((event) => ({ user: readOAuthSession(event) }));

export { session_get as default };
//# sourceMappingURL=session.get.mjs.map
