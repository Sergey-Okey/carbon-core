import { e as createError, j as setCookie, k as getCookie, l as deleteCookie, u as useRuntimeConfig, m as getRequestURL } from './nitro.mjs';
import { randomBytes, createHmac, timingSafeEqual } from 'node:crypto';

const stateCookie = "cof_oauth_state";
const sessionCookie = "cof_auth_session";
function getProviderCredentials(provider) {
  const config = useRuntimeConfig();
  return provider === "google" ? { clientId: config.googleClientId.trim(), clientSecret: config.googleClientSecret.trim() } : { clientId: config.yandexClientId.trim(), clientSecret: config.yandexClientSecret.trim() };
}
function isOAuthProvider(value) {
  return value === "google" || value === "yandex";
}
function getOAuthProviders() {
  const config = useRuntimeConfig();
  const hasSessionSecret = config.authSessionSecret.trim().length >= 32;
  return {
    google: hasSessionSecret && Boolean(config.googleClientId && config.googleClientSecret),
    yandex: hasSessionSecret && Boolean(config.yandexClientId && config.yandexClientSecret)
  };
}
function getCallbackUrl(event, provider) {
  const configuredOrigin = useRuntimeConfig().public.webAppUrl.trim().replace(/\/$/, "");
  const origin = configuredOrigin || getRequestURL(event).origin;
  return `${origin}/api/auth/${provider}/callback`;
}
function createAuthorizationUrl(event, provider) {
  const credentials = getProviderCredentials(provider);
  if (!credentials.clientId || !credentials.clientSecret || !getOAuthProviders()[provider]) {
    throw createError({ statusCode: 503, statusMessage: "OAuth provider is not configured" });
  }
  const state = randomBytes(32).toString("hex");
  setCookie(event, stateCookie, `${provider}:${state}`, cookieOptions(event, 600));
  const callbackUrl = getCallbackUrl(event, provider);
  if (provider === "google") {
    return `https://accounts.google.com/o/oauth2/v2/auth?${new URLSearchParams({
      client_id: credentials.clientId,
      redirect_uri: callbackUrl,
      response_type: "code",
      scope: "openid email profile",
      state,
      prompt: "select_account"
    })}`;
  }
  return `https://oauth.yandex.ru/authorize?${new URLSearchParams({
    client_id: credentials.clientId,
    redirect_uri: callbackUrl,
    response_type: "code",
    state
  })}`;
}
function validateOAuthState(event, provider, state) {
  const expected = getCookie(event, stateCookie);
  deleteCookie(event, stateCookie, cookieOptions(event, 0));
  if (!expected || expected !== `${provider}:${state}`) {
    throw createError({ statusCode: 400, statusMessage: "Invalid OAuth state" });
  }
}
async function exchangeOAuthCode(event, provider, code) {
  const credentials = getProviderCredentials(provider);
  const callbackUrl = getCallbackUrl(event, provider);
  const tokenUrl = provider === "google" ? "https://oauth2.googleapis.com/token" : "https://oauth.yandex.ru/token";
  const tokenResponse = await fetch(tokenUrl, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: credentials.clientId,
      client_secret: credentials.clientSecret,
      code,
      grant_type: "authorization_code",
      redirect_uri: callbackUrl
    })
  });
  if (!tokenResponse.ok) throw createError({ statusCode: 401, statusMessage: "OAuth exchange failed" });
  const token = await tokenResponse.json();
  if (!token.access_token) throw createError({ statusCode: 401, statusMessage: "OAuth token missing" });
  if (provider === "google") {
    const response2 = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
      headers: { authorization: `Bearer ${token.access_token}` }
    });
    const profile2 = await response2.json();
    return normalizeProfile(provider, profile2.sub, profile2.email, profile2.name, profile2.picture);
  }
  const response = await fetch("https://login.yandex.ru/info?format=json", {
    headers: { authorization: `OAuth ${token.access_token}` }
  });
  const profile = await response.json();
  const avatar = profile.default_avatar_id ? `https://avatars.yandex.net/get-yapic/${profile.default_avatar_id}/islands-200` : "";
  return normalizeProfile(
    provider,
    profile.id,
    profile.default_email,
    profile.real_name || profile.display_name,
    avatar
  );
}
function normalizeProfile(provider, id, email, name, avatar) {
  if (!id || !email) throw createError({ statusCode: 401, statusMessage: "OAuth profile incomplete" });
  return { id: `${provider}:${id}`, email, name: name || email.split("@")[0], avatar: avatar || "", provider };
}
function setOAuthSession(event, profile) {
  const sessionProfile = {
    ...profile,
    avatar: profile.avatar.length <= 1024 ? profile.avatar : ""
  };
  const payload = Buffer.from(JSON.stringify(sessionProfile)).toString("base64url");
  const signature = sign(payload);
  setCookie(event, sessionCookie, `${payload}.${signature}`, cookieOptions(event, 60 * 60 * 24 * 30));
}
function readOAuthSession(event) {
  if (useRuntimeConfig().authSessionSecret.trim().length < 32) return null;
  const raw = getCookie(event, sessionCookie);
  if (!raw) return null;
  const [payload, signature] = raw.split(".");
  if (!payload || !signature || !safeEqual(signature, sign(payload))) return null;
  try {
    return JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
  } catch {
    return null;
  }
}
function clearOAuthSession(event) {
  deleteCookie(event, sessionCookie, cookieOptions(event, 0));
}
function sign(payload) {
  const secret = useRuntimeConfig().authSessionSecret.trim();
  if (secret.length < 32) {
    throw createError({ statusCode: 503, statusMessage: "Session secret is not configured" });
  }
  return createHmac("sha256", secret).update(payload).digest("base64url");
}
function safeEqual(left, right) {
  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);
  return leftBuffer.length === rightBuffer.length && timingSafeEqual(leftBuffer, rightBuffer);
}
function cookieOptions(event, maxAge) {
  const secure = getRequestURL(event).protocol === "https:";
  return {
    httpOnly: true,
    sameSite: secure ? "none" : "lax",
    secure,
    path: "/",
    maxAge
  };
}

export { clearOAuthSession as a, createAuthorizationUrl as c, exchangeOAuthCode as e, getOAuthProviders as g, isOAuthProvider as i, readOAuthSession as r, setOAuthSession as s, validateOAuthState as v };
//# sourceMappingURL=oauth.mjs.map
