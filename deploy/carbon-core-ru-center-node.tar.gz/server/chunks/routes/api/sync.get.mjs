import { c as defineEventHandler, e as createError, h as getQuery } from '../../_/nitro.mjs';
import { i as isValidUserId, r as readSyncState } from '../../_/syncStorage.mjs';
import { i as isAuthDatabaseConfigured } from '../../_/authStorage.mjs';
import { r as readOAuthSession } from '../../_/oauth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../_/database.mjs';
import 'pg';

const sync_get = defineEventHandler(async (event) => {
  const session = readOAuthSession(event);
  if (isAuthDatabaseConfigured() && !session) {
    throw createError({ statusCode: 401, statusMessage: "Authentication required" });
  }
  const userId = (session == null ? void 0 : session.id) || getQuery(event).userId;
  if (!isValidUserId(userId)) {
    throw createError({ statusCode: 400, statusMessage: "Invalid userId" });
  }
  return readSyncState(userId);
});

export { sync_get as default };
//# sourceMappingURL=sync.get.mjs.map
