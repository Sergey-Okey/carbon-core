import{aS as s}from"./Bz3aadQW.js";const t=s("/favicon.svg");export{t as _};
