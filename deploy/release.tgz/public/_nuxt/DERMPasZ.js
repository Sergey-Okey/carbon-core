import{h as o}from"./Bz3aadQW.js";const c=o("PlayIcon",[["polygon",{points:"5 3 19 12 5 21 5 3",key:"191637"}]]);export{c as P};
