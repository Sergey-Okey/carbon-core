import { g as getDatabase } from './database.mjs';

async function ensureSubscriptionsTable(sql) {
  await sql`
    CREATE TABLE IF NOT EXISTS cof_subscriptions (
      id BIGSERIAL PRIMARY KEY,
      email TEXT NOT NULL,
      invoice_id TEXT UNIQUE NOT NULL,
      subscription_id TEXT,
      amount NUMERIC(12, 6),
      payment_method TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      paid_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      expires_at TIMESTAMPTZ NOT NULL,
      raw JSONB NOT NULL DEFAULT '{}'::jsonb,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `;
  await sql`CREATE INDEX IF NOT EXISTS cof_subscriptions_email_idx ON cof_subscriptions(email)`;
  await sql`CREATE INDEX IF NOT EXISTS cof_subscriptions_active_idx ON cof_subscriptions(email, expires_at) WHERE status = 'active'`;
}
function normalizeSubscriptionEmail(email) {
  return email.trim().toLowerCase();
}
async function getActiveSubscription(email) {
  const sql = getDatabase();
  if (!sql) return { active: false, expiresAt: "" };
  await ensureSubscriptionsTable(sql);
  const normalizedEmail = normalizeSubscriptionEmail(email);
  if (!normalizedEmail.includes("@")) return { active: false, expiresAt: "" };
  const rows = await sql`
    SELECT expires_at
    FROM cof_subscriptions
    WHERE email = ${normalizedEmail}
      AND status = 'active'
      AND expires_at > NOW()
    ORDER BY expires_at DESC
    LIMIT 1
  `;
  const row = rows[0];
  return row ? { active: true, expiresAt: new Date(String(row.expires_at)).toISOString() } : { active: false, expiresAt: "" };
}
async function hasActiveSubscription(email) {
  return (await getActiveSubscription(email)).active;
}

export { getActiveSubscription as g, hasActiveSubscription as h };
//# sourceMappingURL=subscriptionStorage.mjs.map
