import { c as defineEventHandler } from '../../../_/nitro.mjs';
import { r as readOAuthSession, a as clearOAuthSession, s as setOAuthSession } from '../../../_/oauth.mjs';
import { g as getAccountById } from '../../../_/authStorage.mjs';
import { g as getActiveSubscription } from '../../../_/subscriptionStorage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/database.mjs';
import 'pg';

const session_get = defineEventHandler(async (event) => {
  const session = readOAuthSession(event);
  if (!session) return { user: null, subscription: { active: false, expiresAt: "" } };
  const user = await getAccountById(session.id).catch(() => null);
  if (!user) {
    clearOAuthSession(event);
    return { user: null, subscription: { active: false, expiresAt: "" } };
  }
  const paid = await getActiveSubscription(user.email);
  const subscription = { active: true, expiresAt: paid.expiresAt || "" };
  setOAuthSession(event, user);
  return { user, subscription };
});

export { session_get as default };
//# sourceMappingURL=session.get.mjs.map
