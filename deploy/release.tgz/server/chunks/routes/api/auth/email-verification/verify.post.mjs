import { c as defineEventHandler, e as createError, r as readBody } from '../../../../_/nitro.mjs';
import { i as isAuthDatabaseConfigured, v as verifyEmailCode } from '../../../../_/authStorage.mjs';
import { s as setOAuthSession } from '../../../../_/oauth.mjs';
import { e as enforceRateLimit } from '../../../../_/rateLimit.mjs';
import { g as getActiveSubscription } from '../../../../_/subscriptionStorage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../../_/database.mjs';
import 'pg';

const verify_post = defineEventHandler(async (event) => {
  enforceRateLimit(event, "email-verification-verify", 10, 15 * 60 * 1e3);
  if (!isAuthDatabaseConfigured()) {
    throw createError({ statusCode: 503, statusMessage: "Cloud accounts are not configured" });
  }
  const body = await readBody(event);
  const email = typeof (body == null ? void 0 : body.email) === "string" ? body.email.trim().toLowerCase() : "";
  const code = typeof (body == null ? void 0 : body.code) === "string" ? body.code.trim() : "";
  if (!email.includes("@") || !/^\d{6}$/.test(code)) {
    throw createError({ statusCode: 400, statusMessage: "Verification code is required" });
  }
  const user = await verifyEmailCode(email, code);
  const paid = await getActiveSubscription(user.email);
  const subscription = { active: true, expiresAt: paid.expiresAt || "" };
  setOAuthSession(event, user);
  return { user, subscription };
});

export { verify_post as default };
//# sourceMappingURL=verify.post.mjs.map
