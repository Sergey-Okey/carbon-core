import { c as defineEventHandler, e as createError, r as readBody } from '../../../_/nitro.mjs';
import { i as isAuthDatabaseConfigured, e as createPendingRegistration } from '../../../_/authStorage.mjs';
import { e as enforceRateLimit } from '../../../_/rateLimit.mjs';
import { s as sendMail } from '../../../_/smtp.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/database.mjs';
import 'pg';
import 'node:net';
import 'node:tls';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
function normalizePhone(value) {
  const digits = value.replace(/\D/g, "");
  if (digits.length === 11 && digits.startsWith("8")) return `+7${digits.slice(1)}`;
  if (digits.length === 11 && digits.startsWith("7")) return `+${digits}`;
  if (digits.length === 10) return `+7${digits}`;
  return value.trim();
}
function formatEmailInput(value) {
  return value.replace(/\s+/g, "").toLowerCase();
}
function validateName(value) {
  const name = value.trim();
  if (!name) return "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0438\u043C\u044F";
  if (name.length < 2) return "\u0418\u043C\u044F \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u043A\u043E\u0440\u043E\u0442\u043A\u043E\u0435";
  if (name.length > 40) return "\u0418\u043C\u044F \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0434\u043B\u0438\u043D\u043D\u043E\u0435";
  return "";
}
function validateEmail(value) {
  const email = formatEmailInput(value);
  if (!email) return "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 email";
  if (!EMAIL_RE.test(email)) return "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 email";
  return "";
}
function validatePhone(value) {
  const phone = value.trim();
  if (!phone) return "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043D\u043E\u043C\u0435\u0440 \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0430";
  if (!/^\+7\d{10}$/.test(normalizePhone(phone))) {
    return "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043F\u043E\u043B\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0430";
  }
  return "";
}
function validatePassword(value, { required = true, strict = false } = {}) {
  if (!value) return required ? "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043F\u0430\u0440\u043E\u043B\u044C" : "";
  if (value.length < 8) return "\u041F\u0430\u0440\u043E\u043B\u044C \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u043D\u0435 \u043A\u043E\u0440\u043E\u0447\u0435 8 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432";
  if (value.length > 128) return "\u041F\u0430\u0440\u043E\u043B\u044C \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0434\u043B\u0438\u043D\u043D\u044B\u0439";
  if (strict) {
    if (!/\d/.test(value)) return "\u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u0445\u043E\u0442\u044F \u0431\u044B \u043E\u0434\u043D\u0443 \u0446\u0438\u0444\u0440\u0443";
    if (!/[^\w\s]/.test(value)) return "\u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0439 \u0441\u0438\u043C\u0432\u043E\u043B";
  }
  return "";
}

const register_post = defineEventHandler(async (event) => {
  enforceRateLimit(event, "register", 5, 15 * 60 * 1e3);
  if (!isAuthDatabaseConfigured()) {
    throw createError({ statusCode: 503, statusMessage: "Cloud accounts are not configured" });
  }
  const body = await readBody(event);
  const email = typeof (body == null ? void 0 : body.email) === "string" ? body.email.trim() : "";
  const password = typeof (body == null ? void 0 : body.password) === "string" ? body.password : "";
  const name = typeof (body == null ? void 0 : body.name) === "string" ? body.name.trim() : "";
  const phone = typeof (body == null ? void 0 : body.phone) === "string" ? normalizePhone(body.phone) : "";
  const acceptedTerms = (body == null ? void 0 : body.acceptedTerms) === true;
  const termsVersion = (body == null ? void 0 : body.termsVersion) === "2026-06-07" ? body.termsVersion : "";
  if (validateName(name) || validateEmail(email) || validatePhone(phone) || validatePassword(password)) {
    throw createError({ statusCode: 400, statusMessage: "Invalid registration data" });
  }
  if (!acceptedTerms || !termsVersion) {
    throw createError({ statusCode: 400, statusMessage: "Terms consent is required" });
  }
  try {
    const verification = await createPendingRegistration(
      email,
      password,
      name,
      termsVersion,
      phone
    );
    const sent = await sendMail({
      to: verification.email,
      subject: "\u041A\u043E\u0434 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F Core of Life",
      text: [
        `${verification.name}, \u0437\u0434\u0440\u0430\u0432\u0441\u0442\u0432\u0443\u0439\u0442\u0435.`,
        "",
        "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u044D\u0442\u043E\u0442 \u043A\u043E\u0434 \u0432 Core of Life, \u0447\u0442\u043E\u0431\u044B \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C email:",
        "",
        verification.code,
        "",
        "\u041A\u043E\u0434 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 15 \u043C\u0438\u043D\u0443\u0442. \u0415\u0441\u043B\u0438 \u044D\u0442\u043E \u0431\u044B\u043B\u0438 \u043D\u0435 \u0432\u044B, \u043F\u0440\u043E\u0441\u0442\u043E \u043F\u0440\u043E\u0438\u0433\u043D\u043E\u0440\u0438\u0440\u0443\u0439\u0442\u0435 \u043F\u0438\u0441\u044C\u043C\u043E.",
        "",
        "Core of Life"
      ].join("\n")
    });
    return { requiresVerification: true, email: verification.email, sent };
  } catch (error) {
    if (typeof error === "object" && error !== null && "statusCode" in error) throw error;
    throw createError({ statusCode: 503, statusMessage: "Account database is unavailable" });
  }
});

export { register_post as default };
//# sourceMappingURL=register.post.mjs.map
