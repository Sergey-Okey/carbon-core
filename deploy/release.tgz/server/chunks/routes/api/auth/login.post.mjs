import { c as defineEventHandler, e as createError, r as readBody } from '../../../_/nitro.mjs';
import { i as isAuthDatabaseConfigured, l as loginAccount } from '../../../_/authStorage.mjs';
import { s as setOAuthSession } from '../../../_/oauth.mjs';
import { e as enforceRateLimit } from '../../../_/rateLimit.mjs';
import { g as getActiveSubscription } from '../../../_/subscriptionStorage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/database.mjs';
import 'pg';

const login_post = defineEventHandler(async (event) => {
  enforceRateLimit(event, "login", 10, 15 * 60 * 1e3);
  if (!isAuthDatabaseConfigured()) {
    throw createError({ statusCode: 503, statusMessage: "Cloud accounts are not configured" });
  }
  const body = await readBody(event);
  const email = typeof (body == null ? void 0 : body.email) === "string" ? body.email : "";
  const password = typeof (body == null ? void 0 : body.password) === "string" ? body.password : "";
  if (!email || !password) throw createError({ statusCode: 400, statusMessage: "Email and password are required" });
  let user;
  let subscription;
  try {
    user = await loginAccount(email, password);
    const paid = await getActiveSubscription(user.email);
    subscription = { active: true, expiresAt: paid.expiresAt || "" };
  } catch (error) {
    if (typeof error === "object" && error !== null && "statusCode" in error) throw error;
    throw createError({ statusCode: 503, statusMessage: "Account database is unavailable" });
  }
  setOAuthSession(event, user);
  return { user, subscription };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
