import { c as defineEventHandler, f as getQuery, e as createError } from '../../../_/nitro.mjs';
import { g as getActiveSubscription } from '../../../_/subscriptionStorage.mjs';
import { e as enforceRateLimit } from '../../../_/rateLimit.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/database.mjs';
import 'pg';

const status_get = defineEventHandler(async (event) => {
  enforceRateLimit(event, "subscription-status", 30, 15 * 60 * 1e3);
  const query = getQuery(event);
  const email = typeof query.email === "string" ? query.email : "";
  if (!email.includes("@")) {
    throw createError({ statusCode: 400, statusMessage: "Email is required" });
  }
  return getActiveSubscription(email);
});

export { status_get as default };
//# sourceMappingURL=status.get.mjs.map
