import{aS as s}from"./wHJWp6NW.js";const t=s("/favicon.svg");export{t as _};
