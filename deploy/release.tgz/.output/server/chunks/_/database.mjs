import { u as useRuntimeConfig } from './nitro.mjs';
import { Pool } from 'pg';

let pool = null;
let poolUrl = "";
function getDatabaseUrl() {
  const databaseUrl = useRuntimeConfig().databaseUrl.trim();
  return databaseUrl && !databaseUrl.includes("user:password@host/database") ? databaseUrl : "";
}
function getDatabase() {
  const databaseUrl = getDatabaseUrl();
  if (!databaseUrl) return null;
  if (!pool || poolUrl !== databaseUrl) {
    void (pool == null ? void 0 : pool.end());
    pool = new Pool({
      connectionString: databaseUrl,
      max: 10,
      idleTimeoutMillis: 3e4,
      connectionTimeoutMillis: 5e3
    });
    poolUrl = databaseUrl;
  }
  return async (strings, ...values) => {
    const text = strings.reduce(
      (query, part, index) => query + part + (index < values.length ? `$${index + 1}` : ""),
      ""
    );
    const result = await pool.query(text, values);
    return result.rows;
  };
}

export { getDatabase as g };
//# sourceMappingURL=database.mjs.map
