import { u as useRuntimeConfig } from './nitro.mjs';
import net from 'node:net';
import tls from 'node:tls';

async function sendMail(payload) {
  const config = useRuntimeConfig();
  const host = (config.smtpHost || process.env.SMTP_HOST || "").trim();
  const user = (config.smtpUser || process.env.SMTP_USER || "").trim();
  const password = config.smtpPassword || process.env.SMTP_PASSWORD || "";
  const from = (config.smtpFrom || process.env.SMTP_FROM || "").trim() || user;
  const port = Number(config.smtpPort || process.env.SMTP_PORT || 465);
  if (!host || !user || !password || !from) return false;
  let client = port === 465 ? tls.connect({ host, port, servername: host }) : net.connect({ host, port });
  client.setEncoding("utf8");
  let buffer = "";
  const waitFor = (expected) => new Promise((resolve, reject) => {
    const onData = (chunk) => {
      buffer += chunk;
      const lines = buffer.split(/\r?\n/);
      const last = [...lines].reverse().find((line) => /^\d{3} /.test(line));
      if (!last) return;
      const code = Number(last.slice(0, 3));
      if (!expected.includes(code)) {
        cleanup();
        reject(new Error(`SMTP error ${last}`));
        return;
      }
      const response = buffer;
      buffer = "";
      cleanup();
      resolve(response);
    };
    const onError = (error) => {
      cleanup();
      reject(error);
    };
    const cleanup = () => {
      client.off("data", onData);
      client.off("error", onError);
    };
    client.on("data", onData);
    client.on("error", onError);
  });
  const command = async (line, expected) => {
    client.write(`${line}\r
`);
    await waitFor(expected);
  };
  try {
    await waitFor([220]);
    await command(`EHLO ${host}`, [250]);
    if (port !== 465) {
      await command("STARTTLS", [220]);
      client = tls.connect({ socket: client, servername: host });
      client.setEncoding("utf8");
      await waitForSecureConnect(client);
      buffer = "";
      await command(`EHLO ${host}`, [250]);
    }
    await command("AUTH LOGIN", [334]);
    await command(Buffer.from(user).toString("base64"), [334]);
    await command(Buffer.from(password).toString("base64"), [235]);
    await command(`MAIL FROM:<${extractEmail(from)}>`, [250]);
    await command(`RCPT TO:<${payload.to}>`, [250, 251]);
    await command("DATA", [354]);
    client.write(formatMessage({ ...payload, from }));
    await waitFor([250]);
    await command("QUIT", [221]);
    return true;
  } finally {
    client.end();
  }
}
function extractEmail(value) {
  const match = value.match(/<([^>]+)>/);
  return ((match == null ? void 0 : match[1]) || value).trim();
}
function waitForSecureConnect(client) {
  return new Promise((resolve, reject) => {
    const onSecure = () => {
      cleanup();
      resolve();
    };
    const onError = (error) => {
      cleanup();
      reject(error);
    };
    const cleanup = () => {
      client.off("secureConnect", onSecure);
      client.off("error", onError);
    };
    client.once("secureConnect", onSecure);
    client.once("error", onError);
  });
}
function formatMessage(payload) {
  const headers = [
    `From: ${payload.from}`,
    `To: ${payload.to}`,
    `Subject: =?UTF-8?B?${Buffer.from(payload.subject).toString("base64")}?=`,
    "MIME-Version: 1.0",
    "Content-Type: text/plain; charset=UTF-8",
    "Content-Transfer-Encoding: 8bit"
  ];
  return `${headers.join("\r\n")}\r
\r
${payload.text}\r
.\r
`;
}

export { sendMail as s };
//# sourceMappingURL=smtp.mjs.map
