const storeKeys = [
  "user",
  "tasks",
  "branches",
  "rewards",
  "tags",
  "ui",
  "settings"
];
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isValidUserId(value) {
  return typeof value === "string" && value.length >= 16 && value.length <= 128;
}
function parseSyncPayload(value) {
  if (!isRecord(value) || !isValidUserId(value.userId)) {
    throw new TypeError("Invalid sync payload");
  }
  const payload = { userId: value.userId };
  storeKeys.forEach((key) => {
    const state = value[key];
    if (state !== void 0) {
      if (!isRecord(state)) throw new TypeError(`Invalid ${key} state`);
      payload[key] = state;
    }
  });
  return payload;
}

export { isValidUserId as i, parseSyncPayload as p };
//# sourceMappingURL=syncPayload.mjs.map
