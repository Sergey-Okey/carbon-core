async function getActiveSubscription(_email) {
  return { active: true, expiresAt: "" };
}

export { getActiveSubscription as g };
//# sourceMappingURL=subscriptionStorage.mjs.map
