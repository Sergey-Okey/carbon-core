import { g as getDatabase } from './database.mjs';

async function ensureSyncTable(sql) {
  await sql`
    CREATE TABLE IF NOT EXISTS cof_sync_state (
      user_id TEXT PRIMARY KEY,
      payload JSONB NOT NULL DEFAULT '{}'::jsonb,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `;
}
async function readSyncState(userId) {
  var _a, _b;
  try {
    const sql = getDatabase();
    if (!sql) return {};
    await ensureSyncTable(sql);
    const rows = await sql`
      SELECT payload
      FROM cof_sync_state
      WHERE user_id = ${userId}
      LIMIT 1
    `;
    return (_b = (_a = rows[0]) == null ? void 0 : _a.payload) != null ? _b : {};
  } catch {
    return {};
  }
}
async function writeSyncState(payload) {
  try {
    const sql = getDatabase();
    if (!sql) return { persisted: false, mode: "local" };
    const { userId, ...state } = payload;
    await ensureSyncTable(sql);
    await sql`
      INSERT INTO cof_sync_state (user_id, payload, updated_at)
      VALUES (${userId}, ${JSON.stringify(state)}::jsonb, NOW())
      ON CONFLICT (user_id)
      DO UPDATE SET payload = EXCLUDED.payload, updated_at = NOW()
    `;
    return { persisted: true, mode: "database" };
  } catch {
    return { persisted: false, mode: "local" };
  }
}
async function getDatabaseHealth() {
  const sql = getDatabase();
  if (!sql) return { configured: false, reachable: false };
  await sql`SELECT 1`;
  return { configured: true, reachable: true };
}

export { getDatabaseHealth as g, readSyncState as r, writeSyncState as w };
//# sourceMappingURL=syncStorage.mjs.map
