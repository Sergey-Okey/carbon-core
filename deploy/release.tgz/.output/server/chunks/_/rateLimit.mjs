import { j as getRequestIP, e as createError } from './nitro.mjs';

const attempts = /* @__PURE__ */ new Map();
let nextSweepAt = 0;
function enforceRateLimit(event, scope, limit, windowMs) {
  const now = Date.now();
  if (now >= nextSweepAt) {
    nextSweepAt = now + 60 * 1e3;
    for (const [key2, value] of attempts) {
      if (value.resetAt <= now) attempts.delete(key2);
    }
  }
  const key = `${scope}:${getRequestIP(event, { xForwardedFor: true }) || "unknown"}`;
  const current = attempts.get(key);
  if (!current || current.resetAt <= now) {
    attempts.set(key, { count: 1, resetAt: now + windowMs });
    return;
  }
  if (current.count >= limit) {
    throw createError({ statusCode: 429, statusMessage: "Too many requests. Try again later." });
  }
  current.count += 1;
}

export { enforceRateLimit as e };
//# sourceMappingURL=rateLimit.mjs.map
