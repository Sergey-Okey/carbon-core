import { c as defineEventHandler, f as getQuery } from '../../../_/nitro.mjs';
import { g as getActiveSubscription } from '../../../_/subscriptionStorage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const status_get = defineEventHandler((event) => {
  const query = getQuery(event);
  typeof query.email === "string" ? query.email : "";
  return getActiveSubscription();
});

export { status_get as default };
//# sourceMappingURL=status.get.mjs.map
