import { c as defineEventHandler, e as createError, r as readBody } from '../../../../_/nitro.mjs';
import { i as isAuthDatabaseConfigured, r as resetAccountPassword } from '../../../../_/authStorage.mjs';
import { e as enforceRateLimit } from '../../../../_/rateLimit.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../../_/database.mjs';
import 'pg';

const confirm_post = defineEventHandler(async (event) => {
  enforceRateLimit(event, "password-reset-confirm", 8, 15 * 60 * 1e3);
  if (!isAuthDatabaseConfigured()) {
    throw createError({ statusCode: 503, statusMessage: "Cloud accounts are not configured" });
  }
  const body = await readBody(event);
  const token = typeof (body == null ? void 0 : body.token) === "string" ? body.token.trim() : "";
  const password = typeof (body == null ? void 0 : body.password) === "string" ? body.password : "";
  if (!token || password.length < 8) {
    throw createError({ statusCode: 400, statusMessage: "Invalid reset data" });
  }
  await resetAccountPassword(token, password);
  return { ok: true };
});

export { confirm_post as default };
//# sourceMappingURL=confirm.post.mjs.map
