import { c as defineEventHandler } from '../../../_/nitro.mjs';
import { g as getOAuthProviders } from '../../../_/oauth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const providers_get = defineEventHandler(() => getOAuthProviders());

export { providers_get as default };
//# sourceMappingURL=providers.get.mjs.map
