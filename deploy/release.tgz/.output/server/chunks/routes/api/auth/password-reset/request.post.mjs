import { c as defineEventHandler, e as createError, r as readBody, u as useRuntimeConfig, i as getRequestURL } from '../../../../_/nitro.mjs';
import { i as isAuthDatabaseConfigured, b as createPasswordResetToken } from '../../../../_/authStorage.mjs';
import { e as enforceRateLimit } from '../../../../_/rateLimit.mjs';
import { s as sendMail } from '../../../../_/smtp.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../../_/database.mjs';
import 'pg';
import 'node:net';
import 'node:tls';

const request_post = defineEventHandler(async (event) => {
  enforceRateLimit(event, "password-reset-request", 5, 15 * 60 * 1e3);
  if (!isAuthDatabaseConfigured()) {
    throw createError({ statusCode: 503, statusMessage: "Cloud accounts are not configured" });
  }
  const body = await readBody(event);
  const email = typeof (body == null ? void 0 : body.email) === "string" ? body.email.trim().toLowerCase() : "";
  if (!email.includes("@")) throw createError({ statusCode: 400, statusMessage: "Email is required" });
  const reset = await createPasswordResetToken(email);
  if (!reset) return { ok: true, sent: false };
  const origin = useRuntimeConfig().public.webAppUrl.trim().replace(/\/$/, "");
  const resetUrl = `${origin || getRequestURL(event).origin}/auth?resetToken=${encodeURIComponent(reset.token)}`;
  const sent = await sendMail({
    to: reset.email,
    subject: "\u0412\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u043F\u0430\u0440\u043E\u043B\u044F Core of Life",
    text: [
      `${reset.name}, \u0437\u0434\u0440\u0430\u0432\u0441\u0442\u0432\u0443\u0439\u0442\u0435.`,
      "",
      "\u0412\u044B \u0437\u0430\u043F\u0440\u043E\u0441\u0438\u043B\u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u043F\u0430\u0440\u043E\u043B\u044F \u0432 Core of Life.",
      `\u0421\u0441\u044B\u043B\u043A\u0430 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 30 \u043C\u0438\u043D\u0443\u0442: ${resetUrl}`,
      "",
      "\u0415\u0441\u043B\u0438 \u044D\u0442\u043E \u0431\u044B\u043B\u0438 \u043D\u0435 \u0432\u044B, \u043F\u0440\u043E\u0441\u0442\u043E \u043F\u0440\u043E\u0438\u0433\u043D\u043E\u0440\u0438\u0440\u0443\u0439\u0442\u0435 \u043F\u0438\u0441\u044C\u043C\u043E.",
      "",
      "\u0411\u0435\u0440\u0435\u0433\u0438\u0442\u0435 \u0444\u043E\u043A\u0443\u0441 \u0438 \u0441\u0432\u043E\u0439 \u0440\u0438\u0442\u043C.",
      "Core of Life"
    ].join("\n")
  }).catch((error) => {
    console.error("[auth] password reset mail failed", error);
    return false;
  });
  return { ok: true, sent };
});

export { request_post as default };
//# sourceMappingURL=request.post.mjs.map
