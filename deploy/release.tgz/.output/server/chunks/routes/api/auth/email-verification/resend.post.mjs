import { c as defineEventHandler, e as createError, r as readBody } from '../../../../_/nitro.mjs';
import { i as isAuthDatabaseConfigured, c as createEmailVerificationCode } from '../../../../_/authStorage.mjs';
import { e as enforceRateLimit } from '../../../../_/rateLimit.mjs';
import { s as sendMail } from '../../../../_/smtp.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../../_/database.mjs';
import 'pg';
import 'node:net';
import 'node:tls';

const resend_post = defineEventHandler(async (event) => {
  enforceRateLimit(event, "email-verification-resend", 5, 15 * 60 * 1e3);
  if (!isAuthDatabaseConfigured()) {
    throw createError({ statusCode: 503, statusMessage: "Cloud accounts are not configured" });
  }
  const body = await readBody(event);
  const email = typeof (body == null ? void 0 : body.email) === "string" ? body.email.trim().toLowerCase() : "";
  if (!email.includes("@")) throw createError({ statusCode: 400, statusMessage: "Email is required" });
  const verification = await createEmailVerificationCode(email);
  if (!verification) return { ok: true, sent: false };
  const sent = await sendMail({
    to: verification.email,
    subject: "\u041D\u043E\u0432\u044B\u0439 \u043A\u043E\u0434 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F Core of Life",
    text: [
      `${verification.name}, \u0437\u0434\u0440\u0430\u0432\u0441\u0442\u0432\u0443\u0439\u0442\u0435.`,
      "",
      "\u0412\u0430\u0448 \u043D\u043E\u0432\u044B\u0439 \u043A\u043E\u0434 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F email:",
      "",
      verification.code,
      "",
      "\u041A\u043E\u0434 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 15 \u043C\u0438\u043D\u0443\u0442.",
      "",
      "Core of Life"
    ].join("\n")
  });
  return { ok: true, sent };
});

export { resend_post as default };
//# sourceMappingURL=resend.post.mjs.map
