import { c as defineEventHandler, g as getRouterParam, e as createError, f as getQuery, h as sendRedirect } from '../../../_/nitro.mjs';
import { i as isOAuthProvider, c as createAuthorizationUrl } from '../../../_/oauth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const _provider__get = defineEventHandler((event) => {
  const provider = getRouterParam(event, "provider");
  if (!isOAuthProvider(provider)) {
    throw createError({ statusCode: 404, statusMessage: "Unknown OAuth provider" });
  }
  const query = getQuery(event);
  const termsVersion = query.acceptedTerms === "true" && query.termsVersion === "2026-06-07" ? query.termsVersion : "";
  try {
    return sendRedirect(event, createAuthorizationUrl(event, provider, termsVersion));
  } catch {
    return sendRedirect(event, "/auth?oauthError=provider");
  }
});

export { _provider__get as default };
//# sourceMappingURL=_provider_.get.mjs.map
