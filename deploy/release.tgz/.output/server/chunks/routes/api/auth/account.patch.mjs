import { c as defineEventHandler, e as createError, r as readBody } from '../../../_/nitro.mjs';
import { a as updateAccount } from '../../../_/authStorage.mjs';
import { r as readOAuthSession, s as setOAuthSession } from '../../../_/oauth.mjs';
import { g as getActiveSubscription } from '../../../_/subscriptionStorage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/database.mjs';
import 'pg';

const account_patch = defineEventHandler(async (event) => {
  const session = readOAuthSession(event);
  if (!session) throw createError({ statusCode: 401, statusMessage: "Authentication required" });
  const body = await readBody(event);
  const nextEmail = typeof (body == null ? void 0 : body.email) === "string" ? body.email.trim().toLowerCase() : "";
  const user = await updateAccount(session.id, {
    name: typeof (body == null ? void 0 : body.name) === "string" ? body.name : void 0,
    email: nextEmail || void 0,
    avatar: typeof (body == null ? void 0 : body.avatar) === "string" ? body.avatar : void 0,
    bio: typeof (body == null ? void 0 : body.bio) === "string" ? body.bio : void 0
  });
  setOAuthSession(event, user);
  return { user, subscription: await getActiveSubscription(user.email) };
});

export { account_patch as default };
//# sourceMappingURL=account.patch.mjs.map
