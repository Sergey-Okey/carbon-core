import { c as defineEventHandler, g as getRouterParam, f as getQuery, h as sendRedirect } from '../../../../_/nitro.mjs';
import { i as isOAuthProvider, v as validateOAuthState, s as setOAuthSession, e as exchangeOAuthCode } from '../../../../_/oauth.mjs';
import { u as upsertOAuthAccount } from '../../../../_/authStorage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../../_/database.mjs';
import 'pg';

const callback_get = defineEventHandler(async (event) => {
  const provider = getRouterParam(event, "provider");
  const query = getQuery(event);
  if (!isOAuthProvider(provider) || typeof query.code !== "string" || typeof query.state !== "string") {
    return sendRedirect(event, "/auth?oauthError=invalid");
  }
  try {
    const termsVersion = validateOAuthState(event, provider, query.state);
    setOAuthSession(
      event,
      await upsertOAuthAccount(
        await exchangeOAuthCode(event, provider, query.code),
        termsVersion
      )
    );
    return sendRedirect(event, "/?oauth=success&refresh=1");
  } catch (error) {
    const statusCode = typeof error === "object" && error !== null && "statusCode" in error ? Number(error.statusCode) : 0;
    const reason = statusCode === 403 ? "terms" : statusCode === 401 ? "provider" : "failed";
    const targetPath = reason === "terms" ? "/register" : "/auth";
    return sendRedirect(event, `${targetPath}?oauthError=${reason}`);
  }
});

export { callback_get as default };
//# sourceMappingURL=callback.get.mjs.map
