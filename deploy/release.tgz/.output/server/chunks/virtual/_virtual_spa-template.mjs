const template = "<style>\r\n  html, body {\r\n    margin: 0;\r\n    background: #000;\r\n  }\r\n  #cof-spa-boot {\r\n    position: fixed;\r\n    inset: 0;\r\n    background: #000;\r\n  }\r\n</style>\r\n<div id=\"cof-spa-boot\" role=\"status\" aria-label=\"Загрузка\"></div>";

export { template };
//# sourceMappingURL=_virtual_spa-template.mjs.map
