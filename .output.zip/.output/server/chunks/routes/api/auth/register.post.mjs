import { c as defineEventHandler, e as createError, r as readBody } from '../../../_/nitro.mjs';
import { i as isAuthDatabaseConfigured, r as registerAccount } from '../../../_/authStorage.mjs';
import { s as setOAuthSession } from '../../../_/oauth.mjs';
import { e as enforceRateLimit } from '../../../_/rateLimit.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@neondatabase/serverless';

const register_post = defineEventHandler(async (event) => {
  enforceRateLimit(event, "register", 5, 15 * 60 * 1e3);
  if (!isAuthDatabaseConfigured()) {
    throw createError({ statusCode: 503, statusMessage: "Cloud accounts are not configured" });
  }
  const body = await readBody(event);
  const email = typeof (body == null ? void 0 : body.email) === "string" ? body.email.trim() : "";
  const password = typeof (body == null ? void 0 : body.password) === "string" ? body.password : "";
  const name = typeof (body == null ? void 0 : body.name) === "string" ? body.name.trim() : "";
  const acceptedTerms = (body == null ? void 0 : body.acceptedTerms) === true;
  const termsVersion = (body == null ? void 0 : body.termsVersion) === "2026-06-07" ? body.termsVersion : "";
  if (!email.includes("@") || password.length < 8 || name.length < 2) {
    throw createError({ statusCode: 400, statusMessage: "Invalid registration data" });
  }
  if (!acceptedTerms || !termsVersion) {
    throw createError({ statusCode: 400, statusMessage: "Terms consent is required" });
  }
  let user;
  try {
    user = await registerAccount(email, password, name, termsVersion);
  } catch (error) {
    if (typeof error === "object" && error !== null && "statusCode" in error) throw error;
    throw createError({ statusCode: 503, statusMessage: "Account database is unavailable" });
  }
  setOAuthSession(event, user);
  return { user };
});

export { register_post as default };
//# sourceMappingURL=register.post.mjs.map
