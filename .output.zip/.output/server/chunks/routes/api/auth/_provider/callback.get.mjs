import { c as defineEventHandler, g as getRouterParam, h as getQuery, e as createError, f as sendRedirect } from '../../../../_/nitro.mjs';
import { i as isOAuthProvider, v as validateOAuthState, s as setOAuthSession, e as exchangeOAuthCode } from '../../../../_/oauth.mjs';
import { u as upsertOAuthAccount } from '../../../../_/authStorage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@neondatabase/serverless';

const callback_get = defineEventHandler(async (event) => {
  const provider = getRouterParam(event, "provider");
  const query = getQuery(event);
  if (!isOAuthProvider(provider) || typeof query.code !== "string" || typeof query.state !== "string") {
    throw createError({ statusCode: 400, statusMessage: "Invalid OAuth callback" });
  }
  validateOAuthState(event, provider, query.state);
  setOAuthSession(event, await upsertOAuthAccount(await exchangeOAuthCode(event, provider, query.code)));
  return sendRedirect(event, "/?oauth=success");
});

export { callback_get as default };
//# sourceMappingURL=callback.get.mjs.map
