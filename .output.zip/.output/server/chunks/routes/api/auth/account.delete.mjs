import { c as defineEventHandler, e as createError } from '../../../_/nitro.mjs';
import { r as readOAuthSession, a as clearOAuthSession } from '../../../_/oauth.mjs';
import { d as deleteAccount } from '../../../_/authStorage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@neondatabase/serverless';

const account_delete = defineEventHandler(async (event) => {
  const session = readOAuthSession(event);
  if (!session) throw createError({ statusCode: 401, statusMessage: "Authentication required" });
  await deleteAccount(session.id);
  clearOAuthSession(event);
  return { success: true };
});

export { account_delete as default };
//# sourceMappingURL=account.delete.mjs.map
