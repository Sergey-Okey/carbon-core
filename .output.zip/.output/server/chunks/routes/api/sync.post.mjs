import { c as defineEventHandler, r as readBody, e as createError } from '../../_/nitro.mjs';
import { p as parseSyncPayload, w as writeSyncState } from '../../_/syncStorage.mjs';
import { i as isAuthDatabaseConfigured } from '../../_/authStorage.mjs';
import { r as readOAuthSession } from '../../_/oauth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@neondatabase/serverless';

const sync_post = defineEventHandler(async (event) => {
  let payload;
  try {
    payload = parseSyncPayload(await readBody(event));
  } catch {
    throw createError({ statusCode: 400, statusMessage: "Invalid sync payload" });
  }
  const session = readOAuthSession(event);
  if (isAuthDatabaseConfigured() && !session) {
    throw createError({ statusCode: 401, statusMessage: "Authentication required" });
  }
  if (session) payload.userId = session.id;
  return writeSyncState(payload);
});

export { sync_post as default };
//# sourceMappingURL=sync.post.mjs.map
