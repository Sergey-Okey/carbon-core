import { c as defineEventHandler } from '../../_/nitro.mjs';
import { g as getDatabaseHealth } from '../../_/syncStorage.mjs';
import { g as getOAuthProviders } from '../../_/oauth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@neondatabase/serverless';

const health_get = defineEventHandler(async () => {
  try {
    const database = await getDatabaseHealth();
    return {
      status: !database.configured || database.reachable ? "ok" : "degraded",
      mode: database.configured ? "database" : "local",
      database,
      oauth: getOAuthProviders(),
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
  } catch {
    return {
      status: "degraded",
      mode: "database",
      database: { configured: true, reachable: false },
      oauth: getOAuthProviders(),
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
});

export { health_get as default };
//# sourceMappingURL=health.get.mjs.map
